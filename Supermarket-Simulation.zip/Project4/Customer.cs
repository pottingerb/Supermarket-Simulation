﻿///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Solution/Project:  Project 4
//	File Name:         Registrant.cs
//	Description:       Registrant Class to assign start, interval, id, and HasEvent
//	Course:            CSCI 2210 - Data Structures	
//	Author:            Edgar Guerra, guerrae@etsu.edu, Dept. of Computing, East Tennessee State University
//	Created:           Friday, April 17, 2020
//	Copyright:         Edgar Guerra,Ian Grisham, 2020
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4
{
    class Customer: IComparable
    {
        /// <summary>
        /// properties
        /// </summary>
        public TimeSpan Start { get; set; }// start time
        public TimeSpan Interval { get; set; }// interval
        public string CustomerID { get; set; }// registrant ID
        public Boolean HasEvent { get; set; }// HasEvent boolean to know if the events have been created

        /// <summary>
        /// constructor for the registrant class
        /// </summary>
        /// <param name="start"> start time</param>
        /// <param name="interval"> interval to know end time</param>
        /// <param name="id">user ID</param>
        /// <param name="even">even is short for event to know if they have an event or not</param>
        public Customer(TimeSpan start, TimeSpan interval, int id, Boolean even)
        {
            Start = start;
            Interval = interval;
            CustomerID = id.ToString().PadLeft(4, '0');
            HasEvent = even;
        }

        /// <summary>
        /// implementation of IComparable in case we want to compare objects
        /// </summary>
        /// <param name="obj">the object to be compared</param>
        /// <returns>registrant ID</returns>
        public int CompareTo(object obj)
        {
            if (!(obj is Customer))
            {
                throw new ArgumentException("The argument is not a Registrant object");
            }
            Customer r = (Customer)obj;
            return (r.CustomerID.CompareTo(CustomerID));
        }
    }
}
