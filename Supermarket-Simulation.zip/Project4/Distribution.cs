﻿///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Solution/Project:  Project 4
//	File Name:         Distribution.cs
//	Description:       Class with distribution methods for statistics.
//	Course:            CSCI 2210 - Data Structures	
//	Author:            Edgar Guerra, guerrae@etsu.edu, Dept. of Computing, East Tennessee State University
//	Created:           Friday, April 17, 2020
//	Copyright:         Edgar Guerra, Benjamin Pottinger, 2020
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4
{
    /// <summary>
    /// Public class to access different random distributions.
    /// </summary>
    public class Distribution
    {
        /// <summary>
        /// Negative exponential formula.
        /// </summary>
        /// <param name="expectedValue">The expected value of the formula.</param>
        /// <param name="R">The random class.</param>
        /// <returns>The Negative Exponential solution.</returns>
        public static double NegExp(double expectedValue, Random R)
        {   
            return -expectedValue * Math.Log(R.NextDouble(), Math.E);
        }

        /// <summary>
        /// Normal distribution formula.
        /// </summary>
        /// <param name="expectedValue">The expected value of the formula.</param>
        /// <param name="StdDev">Represents a standard deviation.</param>
        /// <param name="R">An instance of random class.</param>
        /// <returns>The Normal distribution solution.</returns>
        public static double Normal(double expectedValue, double StdDev, Random R)
        {
            double r = Math.Sqrt(-2.0 * Math.Log(R.NextDouble()));
            double Theta = 2.0 * Math.PI * R.NextDouble();
            double Value = r * Math.Sin(Theta);
            return expectedValue + StdDev * Value;
        }

        /// <summary>
        /// Poisson distribution.
        /// </summary>
        /// <param name="expectedValue">The expected value of the formula.</param>
        /// <param name="R">An instance of random class.</param>
        /// <returns>The Poisson distribution solution.</returns>
        public static int Poisson(double expectedValue, Random R)
        {
            double dLimit = -expectedValue;
            double dSum = Math.Log(R.NextDouble());

            int Count;
            for (Count = 0; dSum > dLimit; Count++)
            {
                dSum += Math.Log(R.NextDouble());
            }
            return Count;
        }

    }
}
