///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Solution/Project:  MenuDemo/MenuDemo
//	File Name:         Choices.cs
//	Description:       A set of choices for a Menu in the MenuDriver
//	Course:            CSCI 2210 - Data Structures	
//	Author:            Edgar Guerra, bailes@etsu.edu, Dept. of Computing, East Tennessee State University
//	Created:           Friday, April 17, 2020
//	Copyright:         Edgar Guerra, Benjamin Pottinger, 2020
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace Project4
{

    /// <summary>Sets the four choices for the MenuDriver.</summary>
    enum Choices
    {
        SetRegi = 1, SetHrs, SetWindows, SetChkOut,Run, End
    }
}
