﻿///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Solution/Project:  Project 4
//	File Name:         PriorityQueue.cs
//	Description:       The priority Queue for the project
//	Course:            CSCI 2210 - Data Structures	
//	Author:            Edgar Guerra, guerrae@etsu.edu, Dept. of Computing, East Tennessee State University
//	Created:           Saturday, April 18, 2020
//	Copyright:         Edgar Guerra, Benjamin Pottinger, 2020
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PQ_Wiener
{
    /// <summary>
    /// An implementation of a priority queue.
    /// </summary>
    /// <typeparam name="T">Generic object named T.</typeparam>
    public class PriorityQueue<T>: IPriorityQueue<T> where T:IComparable
    {
        // Fields and properties.
        private Node<T> top; // Reference to the top of the PQ.
        public int Count { get; set; } // Number of items in the PQ.

        /// <summary>
        /// Add an object to priority queue.
        /// </summary>
        /// <param name="item">Generic object to add to queue.</param>
        public void Enqueue(T item)
        {
            if (Count == 0) // If the PQ is empty, execute code.
            {
                top = new Node<T>(item, null); // Add new node with desired item.
            }
            else
            {
                Node<T> current = top;
                Node<T> previous = null;

                // Search for the first node in the linked structure that is smaller than the item.
                while (current != null && current.Item.CompareTo(item) >= 0)
                {
                    previous = current;
                    current = current.Next;
                }

                // Found the place to insert the new node.
                Node<T> newNode = new Node<T>(item, current);

                // If there is a previous node, set it to link to the new node.
                if (previous != null)
                {
                    previous.Next = newNode;// Insert new node.
                }
                else 
                {
                    top = newNode;
                }

            }
            Count++; // Increment the number of nodes in the PQ.
        } // End enqueue method.

        /// <summary>
        /// Remove an object from queue.
        /// </summary>
        public void Dequeue()
        {
            if (IsEmpty()) // If PQ is empty, execute code.
            {
                throw new InvalidOperationException("Cannot remove from empty queue.");
            }

            else
            {
                Node<T> oldNode = top;
                top = top.Next;
                Count--;
                oldNode = null; // Allows the removed node can be garbage collected.
            }
        }


        /// <summary>
        /// Empties the PQ of all objects.
        /// </summary>
        public void Clear()
        {
            top = null; // Nodes will be garbage collected.
            Count = 0;	// Count is now 0 since PQ is empty.
        }

        /// <summary>
        /// Retrieves the top object in the PQ.
        /// </summary>
        /// <returns>Top object in PQ if not empty.</returns>
        public T Peek()
        {
            if (!IsEmpty())
            {
                return top.Item;
            }
            else
            {
                throw new InvalidOperationException("Cannot obtain top of empty priority queue.");
            }
        }

        /// <summary>
        /// Determines whether the PQ is empty.
        /// </summary>
        /// <returns>true if empty</returns>
        public bool IsEmpty() 
        {
            return Count == 0; // Empty if count is equal to 0.
        }

    }
}
