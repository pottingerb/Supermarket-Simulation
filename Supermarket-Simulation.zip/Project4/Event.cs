﻿///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Solution/Project:  Project 4
//	File Name:         Event.cs
//	Description:       Event class to assign leave or enter type.
//	Course:            CSCI 2210 - Data Structures	
//	Author:            Edgar Guerra, guerrae@etsu.edu, Dept. of Computing, East Tennessee State University
//	Created:           Friday, April 17, 2020
//	Copyright:         Edgar Guerra, Benjamin Pottinger, 2020
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4
{
    enum EVENTTYPE { ENTER, LEAVE };
    class Event : IComparable
    {
        /// <summary>
        /// Properties.
        /// </summary>
        public EVENTTYPE Type { get; set; } // Type of event occurrence.
        public DateTime Time { get; set; } // Time of event occurrence.
        public Customer Registrant { get; set; } // Registrant ID.

        
        /// <summary>
        /// Parameterized constructor for this class.
        /// </summary>
        /// <param name="type">The event type.</param>
        /// <param name="time">The time of the event occurrence.</param>
        /// <param name="registrant">Registrant ID.</param>
        public Event(EVENTTYPE type, DateTime time, Customer registrant)
        {
            Type = type;
            Time = time;
            Registrant = registrant;
        }

        /// <summary>
        /// The String representation of an event object. Overrides default ToString method.
        /// </summary>
        /// <returns>event in string form</returns>
        public override string ToString()
        {
            string str = "";
            str += String.Format("Registrant {0}",Registrant.CustomerID.PadLeft(3));
            str += Type + "'s";
            str += String.Format(" at {0}", Time.ToShortTimeString().PadLeft(8));
            return str;
        }

        /// <summary>
        /// Comparison to determine the event is an object.
        /// </summary>
        /// <param name="obj">The time of the event.</param>
        /// <returns>dateTime</returns>
        public int CompareTo(Object obj)
        {
            if (!(obj is Event))
            {
                throw new ArgumentException("The argument is not an Event object");
            }
            Event e = (Event)obj;
            return (e.Time.CompareTo(Time));
        }

    }
}
	

	

