﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PQ_Wiener;
using System.Threading;
using System.Collections;
using Project4;
namespace Project5
{
    class ConventionRegistration
    {
        private static List<Registrant> registrants = new List<Registrant>(); // list of registrant id's
        private static Random r = new Random(); /// random class
        private static List<Queue<Registrant>> conventionWindows = new List<Queue<Registrant>>();// windows
        private static PriorityQueue<Event> PQ = new PriorityQueue<Event>();/// Event type PriorityQueue 
        private static DateTime timeWeOpen;/// time opened class
        private static int maxPresent = 0;/// largest number present during simulation
        private static TimeSpan shortest,   //shortest stay
                                longest,    //longest stay
                                totalTime;  //totalTime

        public double ConventionHours { get; set; }// hours open
        public int NumberOfWindows { get; set; } // number of windows
        public double AverageWaitingTime { get; set; } // avg waiting time
        public int RegistrantCount { get; set; } // number of registrants
        public int Queuemin { get; set; } // gets the queue min ammount
        public int MaxQueueCount { get; set; }// gets max queue count
        public int MinQueueID { get; set; }
        public int ammountLeft { get; set; }
        public int ammountArrived { get; set; }

        public ConventionRegistration(double conventionHours, int numberOfWindows, double avgWaitingTime, int registCount)
        {
            //setting all getters and setters
            ConventionHours = conventionHours;
            NumberOfWindows = numberOfWindows;
            AverageWaitingTime = avgWaitingTime;
            RegistrantCount = Distribution.Poisson(registCount, r);
            timeWeOpen = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day, 8, 0, 0);
            //creating queues
            for (int i = 0; i < NumberOfWindows; i++)
            {

                Queue<Registrant> window = new Queue<Registrant>(); // single line
                conventionWindows.Add(window);// creates all the windows
            }
            conventionWindows.TrimExcess();
        }

        public void CreateEvents()
        {
            TimeSpan start;
            TimeSpan interval;
            shortest = new TimeSpan(0, 1, 30);
            longest = new TimeSpan(0, 0, 0);
            totalTime = new TimeSpan(0, 0, 0);
            //MinQueueID = 0;//queue id of min
            //MaxQueueCount = 0;

            ammountLeft = 0;// amount who left
            ammountArrived = 0;// ammount arrived
            Queuemin = 1000; // set queue min

            for (int i = 1; i < RegistrantCount; i++)
            {
                //Random start time based on number of min. in the 10 hours open
                start = new TimeSpan(0, r.Next((int)ConventionHours * 60), 0);

                //random (neg. exp) interval with a min of 1.5 min; expected time 4.5
                interval = new TimeSpan(0, (int)(1.5 + Distribution.NegExp(AverageWaitingTime, r)), 0);
                totalTime += interval;
                if (shortest > interval)
                    shortest = interval;
                if (longest < interval)
                    longest = interval;
                Registrant regi = new Registrant(start, interval, RegistrantCount, true);
                registrants.Add(regi);
                RegistrantCount--;
                PQ.Enqueue(new Event(EVENTTYPE.ENTER, timeWeOpen.Add(start), regi));// enqueue arrival
                ammountArrived++;
            }


        }
        public void DoSimulation()
        {
            TimeSpan start;
            TimeSpan interval;
            shortest = new TimeSpan(0, 1, 30);
            longest = new TimeSpan(0, 0, 0);
            totalTime = new TimeSpan(0, 0, 0);
            //MinQueueID = 0;//queue id of min
            //MaxQueueCount = 0;

            ammountLeft = 0;// amount who left
            ammountArrived = 0;// ammount arrived
            Queuemin = 1000; // set queue min


            //Random start time based on number of min. in the 10 hours open
            start = new TimeSpan(0, r.Next((int)ConventionHours * 60), 0);

            //random (neg. exp) interval with a min of 1.5 min; expected time 4.5
            interval = new TimeSpan(0, (int)(1.5 + Distribution.NegExp(AverageWaitingTime, r)), 0);
            totalTime += interval;
            shortest = interval;
            longest = interval;
            Registrant regi = new Registrant(start, interval, RegistrantCount, true);
            registrants.Add(regi);
            RegistrantCount--;
            PQ.Enqueue(new Event(EVENTTYPE.ENTER, timeWeOpen.Add(start), regi));// enqueue arrival
            PQ.Enqueue(new Event(EVENTTYPE.LEAVE, timeWeOpen.Add(start + interval), regi)); //enqueue departure
            conventionWindows[0].Enqueue(regi);
            ammountArrived++;

            while (PQ.Count > 0) // loop throuhg prio queue
            {
                if (PQ.Count != 0) // check if pq is not empty
                {
                    if (PQ.Peek().Type == EVENTTYPE.LEAVE) // is leave event
                    {
                        for (int i = 0; i < conventionWindows.Count; i++)//go through each queue and find the register
                        {
                            Console.WriteLine(PQ.Peek());
                            if (conventionWindows[i].Count != 0)
                            {
                                if (conventionWindows[i].Peek().RegistrantID == PQ.Peek().Registrant.RegistrantID) //if id matches
                                {
                                    TimeSpan newStart = PQ.Peek().Registrant.Start;
                                    TimeSpan newInterval = PQ.Peek().Registrant.Interval;
                                    PQ.Dequeue();
                                    conventionWindows[i].Dequeue();
                                    RegistrantCount--;
                                    ammountLeft++;
                                    if (conventionWindows[i].Count != 0)
                                    {
                                        if (conventionWindows[i].Peek().HasEvent == false)
                                        {
                                            conventionWindows[i].Peek().HasEvent = true;
                                            PQ.Enqueue(new Event(EVENTTYPE.ENTER, timeWeOpen.Add(newStart + newInterval), conventionWindows[i].Peek()));// enqueue arrival
                                            PQ.Enqueue(new Event(EVENTTYPE.LEAVE, timeWeOpen.Add(conventionWindows[i].Peek().Start + conventionWindows[i].Peek().Interval), conventionWindows[i].Peek())); //enqueue departure

                                            break;
                                        }

                                    }
                                    break;
                                }
                            }
                        }
                    }
                    else // even is an enter event
                    {
                        int eCounter = 0;
                        while (PQ.Peek().Type == EVENTTYPE.ENTER) // while the event is an enter event
                        {
                            for (int i = 0; i < conventionWindows.Count; i++) // loop through queue's
                            {
                                eCounter++;
                                if (conventionWindows[i].Count != 0) // if queue is not empty
                                {
                                    if (PQ.Peek().Registrant.RegistrantID == conventionWindows[i].Peek().RegistrantID) // and if regi are equal
                                    {
                                        PQ.Dequeue();
                                        break;
                                    }

                                }
                            }
                            if (eCounter >= conventionWindows.Count)
                            {
                                PQ.Dequeue();
                                break;
                            }
                        }

                    }
                } // END OF: if pq is not empty check for the event 

                for (int i = 0; i < conventionWindows.Count; i++) // get queue with the least ammount of useres
                {
                    if (conventionWindows[i].Count <= Queuemin) // if has least ammount
                    {
                        Queuemin = conventionWindows[i].Count; // get queuemin
                        MinQueueID = i;

                    }
                }

                if (conventionWindows[MinQueueID].Count == 0)
                {
                    //Random start time based on number of min. in the 10 hours open
                    start = new TimeSpan(0, r.Next((int)ConventionHours * 60), 0);
                    //random (neg. exp) interval with a min of 1.5 min; expected time 4.5
                    interval = new TimeSpan(0, (int)(1.5 + Distribution.NegExp(AverageWaitingTime, r)), 0);
                    totalTime += interval;
                    if (shortest > interval)
                        shortest = interval;
                    if (longest < interval)
                        longest = interval;
                    regi = new Registrant(start, interval, RegistrantCount, true);
                    registrants.Add(regi);
                    RegistrantCount--;
                    PQ.Enqueue(new Event(EVENTTYPE.ENTER, timeWeOpen.Add(start), regi));// enqueue arrival
                    PQ.Enqueue(new Event(EVENTTYPE.LEAVE, timeWeOpen.Add(start + interval), regi)); //enqueue departure
                    conventionWindows[MinQueueID].Enqueue(regi);
                    Queuemin = 1000;
                    ammountArrived++;
                }
                else
                {
                    //Random start time based on number of min. in the 10 hours open
                    start = new TimeSpan(0, r.Next((int)ConventionHours * 60), 0);
                    //random (neg. exp) interval with a min of 1.5 min; expected time 4.5
                    interval = new TimeSpan(0, (int)(1.5 + Distribution.NegExp(AverageWaitingTime, r)), 0);
                    totalTime += interval;
                    if (shortest > interval)
                        shortest = interval;
                    if (longest < interval)
                        longest = interval;
                    regi = new Registrant(start, interval, RegistrantCount, false);
                    ammountArrived++;
                    conventionWindows[MinQueueID].Enqueue(regi);
                    Queuemin = 1000;
                }

                for (int i = 0; i < conventionWindows.Count; i++) // find max queue count
                {
                    if (conventionWindows[i].Count >= MaxQueueCount)
                    {
                        MaxQueueCount = conventionWindows[i].Count;
                    }
                }
                //List<Queue<Registrant>> tempList = conventionWindows;
                List<Queue<Registrant>> newQueue = new List<Queue<Registrant>>();
                List<Queue<string>> stringQueue = new List<Queue<string>>();
                for (int i = 0; i < NumberOfWindows; i++)
                {
                    Queue<string> newSTQ = new Queue<string>();
                    Queue<Registrant> tempQueue = new Queue<Registrant>();
                    newQueue.Add(tempQueue);
                    stringQueue.Add(newSTQ);
                }
                // update queue to have same ammount of items
                for (int i = 0; i < conventionWindows.Count; i++)
                {
                    var copy = new Queue<Registrant>(conventionWindows[i]);
                    newQueue[i] = copy;

                    for (int w = 0; w < newQueue[i].Count; w++)
                    {
                        while (newQueue[i].Count != 0)
                        {
                            stringQueue[i].Enqueue(newQueue[i].Peek().RegistrantID);
                            newQueue[i].Dequeue();
                        }

                    }

                }

                for (int i = 0; i < stringQueue.Count; i++)
                {
                    if (stringQueue[i].Count != MaxQueueCount) // if convention windows i count does not equal maxqueuecount
                    {
                        for (int w = stringQueue[i].Count; w < MaxQueueCount; w++) // loop through the list and add an empty string until all list are same size
                        {
                            stringQueue[i].Enqueue("    ");
                        }
                    }
                }

                StringBuilder heading = new StringBuilder();
                Console.WriteLine("\n\n");
                heading.Append("\t\t");
                for (int i = 0; i < stringQueue.Count; i++)
                {
                    heading.Append(" W " + i + "".PadRight(16));
                }
                Console.WriteLine(heading.ToString());
                Console.WriteLine("\n\n");
                StringBuilder QSB = new StringBuilder();
                QSB.Append("\t\t");
                for (int i = 0; i <= MaxQueueCount; i++) // loop through the max queue height
                {
                    QSB.Clear();
                    QSB.Append("\t\t");

                    for (int c = 0; c < stringQueue.Count; c++) // loop through all the windows
                    {
                        //while (stringQueue[c].Count != 0)
                        //{
                        //    QSB.Append(stringQueue[c].Peek() + "".PadRight(16));
                        //    stringQueue[c].Dequeue();
                        //}
                        //for (int w = 0; w < stringQueue[c].Count; w++)
                        //{
                        if (stringQueue[c].Count != 0)
                        {
                            QSB.Append(stringQueue[c].Peek() + "".PadRight(16));
                            stringQueue[c].Dequeue();
                        }

                        //}


                    }
                    Console.WriteLine(QSB.ToString() + "\n");


                }



                Console.WriteLine("----------------------------------------------------------------------------------------------\n\n");
                Console.WriteLine("Max Queue Count: " + MaxQueueCount);
                Console.WriteLine("Ammount Arrived: " + ammountArrived);
                Console.WriteLine("Ammount Departed: " + ammountLeft);
                Console.WriteLine("Registrants Left: " + RegistrantCount);
                Console.WriteLine("Min Queue ID: " + MinQueueID);
                Console.WriteLine("PRIORITY " + PQ.Count);
                Thread.Sleep(500);
                Console.Clear();

                if (RegistrantCount == 0)
                {
                    Console.ReadKey();
                }

            }

        }





    }
}
