﻿///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Solution/Project:  Project 4
//	File Name:         ConventionRegistration.cs
//	Description:       Simulation of a convention that gathers statistics.
//	Course:            CSCI 2210 - Data Structures	
//	Author:            Edgar Guerra, guerrae@etsu.edu, Dept. of Computing, East Tennessee State University
//	Created:           Monday, April 20, 2020
//	Copyright:         Edgar Guerra, Benjamin Pottinger, Ian Grisham, 2020
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PQ_Wiener;
using System.Threading;
using System.Collections;

namespace Project4
{
    /// <summary>
    /// Simulation of a convention that gathers statistics
    /// </summary>
    class SuperMarket
    {
        /// <summary>
        /// Static variable declaration.
        /// </summary>
        private static List<Customer> customers = new List<Customer>(); // List of customer IDs.
        private static Random r = new Random(); /// Generic random object.
        public static List<Queue<Customer>> Register = new List<Queue<Customer>>(); // check out register
        private static PriorityQueue<Event> PQ = new PriorityQueue<Event>(); // Object of event type PriorityQueue.
        private static DateTime timeWeOpen; // Stores the time the queue is opened. 
        private static TimeSpan shortest,   // The shortest duration of a stay.
                                longest,    // The longest duration of a stay.
                                totalTime;  // The total time spent in the supermarket.

        /// <summary>
        /// Getters and setters for all the static variables.
        /// </summary>
        public double MarketHours { get; set; }// The number of hours open.
        public int NumberOfWindows { get; set; } // The number of windows.
        public double AverageWaitingTime { get; set; } // The average waiting time.
        public int CustomerCount { get; set; } // The number of customers.
        public int Queuemin { get; set; } // The queue min amount.
        public int MaxQueueCount { get; set; } // The max queue count.
        public int MinQueueID { get; set; } // The min queue id.
        public int amountLeft { get; set; } // The amount of users left.
        public int amountArrived { get; set; } // The amount of people who have arrived.

        /// <summary>
        /// The parameterized constructor for this class.
        /// </summary>
        /// <param name="Hours">Gets and sets convention hours.</param>
        /// <param name="numberOfWindows"> Gets and sets number of windows.</param>
        /// <param name="avgWaitingTime"> Gets and sets average waiting time.</param>
        /// <param name="registCount">Gets and sets total registrant count.</param>
        public SuperMarket(double Hours, int numberOfWindows, double avgWaitingTime, int registCount)
        {
            // Setting all getters and setters.
            MarketHours = Hours;
            NumberOfWindows = numberOfWindows;
            AverageWaitingTime = avgWaitingTime;
            CustomerCount = Distribution.Poisson(registCount, r);
            timeWeOpen = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day, 8, 0, 0);
        }

        /// <summary>
        /// Creates all enter queue based on the registrant count.
        /// </summary>
        public void CreateEvents() 
        {
            TimeSpan start;
            TimeSpan interval;
            shortest = new TimeSpan(0, 2, 0);
            longest = new TimeSpan(0, 0, 0);
            totalTime = new TimeSpan(0, 0, 0);
          

            amountLeft = 0; // Amount of customers who have left.
            amountArrived = 0;// Amount of customers who have arrived.
            Queuemin = 1000; // Set queue minimum.

            for (int i = 1; i < CustomerCount; i++)
            {
                // Random start time based on number of minimum in the 16 hours open.
                start = new TimeSpan(0, r.Next((int)MarketHours * 60), 0);

                // Random (neg. exp) interval with a minimum of 2 minutes; expected time 4.5 minutes.
                double tempDist = Distribution.NegExp(AverageWaitingTime, r);
                if (tempDist <= 2.0)
                {
                    interval = new TimeSpan(0, 2, 0);
                }
                else
                {
                    interval = new TimeSpan(0, (int)(tempDist), 0);
                }
                totalTime += interval;
                if (shortest > interval)
                    shortest = interval;
                if (longest < interval)
                    longest = interval;
                Customer regi = new Customer(start, interval, i, true);
                customers.Add(regi);
                PQ.Enqueue(new Event(EVENTTYPE.ENTER, timeWeOpen.Add(start), regi));// enqueue arrival
            }
           

        }

        /// <summary>
        /// Does the simulation for the convention.
        /// </summary>
        public void DoSimulation()
        {
            amountLeft = 0; // Amount of customers who have left.
            amountArrived = 0;// Amount of customers who have arrived.
            Queuemin = 1000; // Set queue minimum.

            // Creating queue instances in conventionWindow.
            for (int i = 0; i < NumberOfWindows; i++)
            {

                Queue<Customer> window = new Queue<Customer>(); // Single line.
                Register.Add(window);// Creates all the windows.
            }

            Register.TrimExcess();
        
            while (PQ.Count > 0) // Loop through priority queue.
            {
                if (PQ.Count != 0) // Check if PQ is not empty.
                {
                    if (PQ.Peek().Type == EVENTTYPE.LEAVE) // If PQ type is a leave event, then execute.
                    {
                        for (int i = 0; i < Register.Count; i++)// Iterate through each queue and find the register.
                        {
                            if (Register[i].Count != 0) // If convention window is not 0, then execute.
                            {
                                if (Register[i].Peek().CustomerID == PQ.Peek().Registrant.CustomerID) // If ID matches, then execute.
                                {
                                    TimeSpan newStart = PQ.Peek().Registrant.Start;
                                    TimeSpan newInterval = PQ.Peek().Registrant.Interval;
                                    PQ.Dequeue();
                                    Register[i].Dequeue();
                                    amountLeft++;
                                    if (Register[i].Count != 0)// If convention window is not 0, then execute.
                                    {
                                        if (Register[i].Peek().HasEvent == false)
                                        {
                                            Register[i].Peek().HasEvent = true;
                                            PQ.Enqueue(new Event(EVENTTYPE.LEAVE, timeWeOpen.Add(Register[i].Peek().Start + Register[i].Peek().Interval), Register[i].Peek())); // Enqueue departure.

                                            break;
                                        }

                                    }
                                    break;
                                }
                            }
                        }
                    }
                    else // Otherwise, even is an enter event. Execute code.
                    {
                        for (int i = 0; i < Register.Count; i++) // Get queue with the least amount of users.
                        {
                            if (Register[i].Count <= Queuemin) // If has least amount, then execute.
                            {
                                Queuemin = Register[i].Count; // Get queue minimum.
                                MinQueueID = i;

                            }
                        }
                        if (Register[MinQueueID].Count == 0) // If min window count is 0, then execute.
                        {
                            Register[MinQueueID].Enqueue(PQ.Peek().Registrant);
                            amountArrived++;
                            PQ.Peek().Registrant.HasEvent = true;
                            PQ.Dequeue();
                            PQ.Enqueue(new Event(EVENTTYPE.LEAVE, timeWeOpen.Add(Register[MinQueueID].Peek().Start + Register[MinQueueID].Peek().Interval), Register[MinQueueID].Peek()));
                            Queuemin = 1000;
                        }
                        else // Event window is not 0 so registrant has to wait his turn.
                        {
                            Register[MinQueueID].Enqueue(PQ.Peek().Registrant);
                            amountArrived++;
                            PQ.Peek().Registrant.HasEvent = false;
                            PQ.Dequeue();
                            Queuemin = 1000;
                        }
                    }
                        
                } // END OF: if PQ is not empty check for the event.

                for (int i = 0; i < Register.Count; i++) // Find max queue count.
                {
                    if (Register[i].Count >= MaxQueueCount)
                    {
                        MaxQueueCount = Register[i].Count; 
                    }
                }
                
                List<Queue<Customer>> newQueue = new List<Queue<Customer>>(); // Temporary list queue of customers.
                List<Queue<string>> stringQueue = new List<Queue<string>>(); // Temporary string queue for registrant ID.
                for (int i = 0; i < NumberOfWindows; i++) // Loop through window count and set the queues/
                {
                    Queue<string> newSTQ = new Queue<string>();
                    Queue<Customer> tempQueue = new Queue<Customer>();
                    newQueue.Add(tempQueue);
                    stringQueue.Add(newSTQ);
                }
               // Update queue to have same amount of items.
                for (int i = 0; i < Register.Count; i++)
                {
                    var copy = new Queue<Customer>(Register[i]);
                    if (copy.Count !=0)
                    {
                        newQueue[i] = copy;
                    }
                       

                    for (int w = 0; w < newQueue[i].Count; w++)
                    {
                        while (newQueue[i].Count!=0)
                        {
                            stringQueue[i].Enqueue(newQueue[i].Peek().CustomerID);
                                                    newQueue[i].Dequeue();
                        }
                        
                    }
                   
                }

                for (int i = 0; i < stringQueue.Count; i++)
                {
                    if (stringQueue[i].Count != MaxQueueCount) // If convention windows i count does not equal the max queue count, execute code.
                    {
                        for (int w = stringQueue[i].Count; w < MaxQueueCount; w++) // Loop through the list and add an empty string until all lists are the same size.
                        {
                            stringQueue[i].Enqueue("    ");
                        }
                    }
                }

                StringBuilder heading = new StringBuilder();
                Console.WriteLine("\n\n");
                heading.Append("\t\t");
                for (int i = 0; i < stringQueue.Count; i++) // Create all the windows in the console.
                {
                    heading.Append(" W " + i+"".PadRight(16));
                }
                Console.WriteLine(heading.ToString());
                Console.WriteLine("\n\n");
                StringBuilder QSB = new StringBuilder();
                QSB.Append("\t\t");
                for (int i = 0; i <= MaxQueueCount; i++) // Loop through the max queue height.
                {
                    QSB.Clear();
                    QSB.Append("\t\t");

                    for (int c = 0; c < stringQueue.Count; c++) // Loop through all the windows.
                    {
                            if (stringQueue[c].Count != 0)
                            {
                                QSB.Append(stringQueue[c].Peek() + "".PadRight(16));
                                stringQueue[c].Dequeue();
                            }
                    }
                    Console.WriteLine(QSB.ToString() + "\n");


                }
                
                // Statistics output to console.

                Console.WriteLine("----------------------------------------------------------------------------------------------\n\n");
                Console.WriteLine("Longest Queue Encountered So Far: " + MaxQueueCount);
                Console.WriteLine("Events Processed So Far: " + (amountArrived + amountLeft) + "\tArrivals: " + amountArrived + "\tDepartures: " + amountLeft);
                Thread.Sleep(75);
                if (PQ.Count == 0)
                {
                    AverageWaitingTime = (totalTime.TotalSeconds / CustomerCount) / 60;
                    
                    Console.WriteLine("The average service time for " + CustomerCount + " Registrants was " + AverageWaitingTime + ".");
                    Console.WriteLine("The minimum service times was " + shortest.ToString() + " and the maximum service time was " + longest.ToString()); 
                    Console.ReadKey();
                }
                Console.Clear();

                

            }
            
        }

    }
}
